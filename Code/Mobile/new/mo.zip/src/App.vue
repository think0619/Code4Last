<template>
  <div id="app"> 
    <router-view />
  </div>
</template>

<script setup>
import './assets/css/index.css'
</script>

<style>
body {
  font-size: 16px; 
  background-size: cover;
  -webkit-font-smoothing: antialiased;
  margin: 0;
  padding: 0;
  border: 0
}
</style>
